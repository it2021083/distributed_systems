package com.example.eagrotis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EagrotisApplicationTests {

	@Test
	void contextLoads() {
	}

}
