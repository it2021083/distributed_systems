package com.example.eagrotis.entity;

import jakarta.persistence.Entity;

import java.sql.Date;

@Entity
public class Farmer extends User{
    public Farmer() {
    }

    public Farmer(String username, String name, String password, Date birthDate) {
        super(username, name, password, birthDate);
    }

    @Override
    public String toString() {
        return "User{" +
                "Id=" + getId() +
                ", Username='" + getUsername() + '\'' +
                ", Name='" + getName() + '\'' +
                ", Birthdate='" + getBirthDate() + '\'' +
                '}';
    }
}
