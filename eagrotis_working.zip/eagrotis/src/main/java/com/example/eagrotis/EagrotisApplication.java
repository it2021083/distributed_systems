package com.example.eagrotis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EagrotisApplication {

	public static void main(String[] args) {
		SpringApplication.run(EagrotisApplication.class, args);
	}

}
